#pragma once

#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <iostream>
#include <iterator>
#include <bits/stdc++.h>

#include <functional>
#include <thread>

#include <vector>
#include <string>
#include <stack>
#include <unordered_map>